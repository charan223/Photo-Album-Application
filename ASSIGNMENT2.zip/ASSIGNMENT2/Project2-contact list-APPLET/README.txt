CONTACT LIST
APPLET
First use new data button...and after filling details use exit option...run it again...then we can use old data button to read old data

