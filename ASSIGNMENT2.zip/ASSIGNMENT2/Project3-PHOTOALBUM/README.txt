PHOTO ALBUM ASSIGNMENT

There is no requirement for predefined instructions as everything is clear